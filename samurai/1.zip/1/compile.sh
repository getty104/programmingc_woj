g++ -W -Wall -O2 -march=native -o greedy greedy.cpp raceState.cpp
